<!-- begin header -->
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Pages List</title>

<!-- package css-->
<link href="css/pages-package.css" rel="stylesheet" type="text/css">
<!-- end header -->

 <!-- begin footer -->
<script type="text/javascript">
   
    </script> 
    <!-- <script src="https://unpkg.com/vue/dist/vue.min.js"></script> -->
    <script src="https://cdn.jsdelivr.net/npm/vue@2.6.12/dist/vue.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/axios/0.19.2/axios.js"></script>
    <script type="text/javascript" src="scripts/package.js"></script>


<!-- end footer --> 
